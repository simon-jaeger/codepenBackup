/*

just a little demo of how one could
implement a few basic layout components
with css grid

*/