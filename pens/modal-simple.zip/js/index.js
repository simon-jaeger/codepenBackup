$(".button[data-target]").click(function() {
  $("#" + this.dataset.target).toggleClass("-open")
})

$(".modal").click(function(e) {
  if (e.target === this) {
    $(this).toggleClass("-open")
  }
})