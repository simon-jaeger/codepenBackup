const $burger = $(".burger")
const $bars = $burger.children()

const burgerTL = new TimelineLite()
burgerTL
  .to($bars[0], 0.2, { yPercent: 200 }, 0)
  .to($bars[2], 0.2, { yPercent: -200 }, 0)
  .to($bars[1], 0.001, { autoAlpha: 0 }) // *
  .addLabel("rotate")
  .to($bars[0], 0.2, { rotation: 45 }, "rotate")
  .to($bars[2], 0.2, { rotation: -45 }, "rotate")
  .reverse()

$burger.click(() => {
  burgerTL.reversed(!burgerTL.reversed())
})

// *
// use 0.001 instead of 0 to avoid rendering issues
// with 0, the middle bar would sometimes not toggle