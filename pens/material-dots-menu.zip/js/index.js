$(".bar_dots").click(() => {
  // only change on next tick to avoid closing immediately
  requestAnimationFrame(() => {
    $(".bar_menu").addClass("-open")
  })
})

$(window).click(() => {
  $(".bar_menu").removeClass("-open")
})