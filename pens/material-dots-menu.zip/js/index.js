$(window).click(e => {
  if ($(e.target).is(".bar_dots")) {
    $(".bar_menu").addClass("-open")  
  } else {
    $(".bar_menu").removeClass("-open")
  }
})