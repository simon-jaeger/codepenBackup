const $img = $(".img")
const $width = $("#width")
const $height = $("#height")
const $fitButtons = $(".fit_button")
let fitMode = "contain"

function updateImg() {
  $img.css({
    width: $width.val(),
    height: $height.val(),
    objectFit: fitMode
  })
}

$width.add($height).on("input", updateImg)
$fitButtons.click(function() {
  $(this)
    .addClass("-active")
    .siblings()
    .removeClass("-active")
  fitMode = $(this).text()
  updateImg()
})