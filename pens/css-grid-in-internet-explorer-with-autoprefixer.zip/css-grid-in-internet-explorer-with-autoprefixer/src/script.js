/*

this layout works in internet explorer.
it uses autoprefixer's grid mode.

*/