$(".rating").click(function(e) {
  const $this = $(this)
  const $target = $(e.target)
  const $icon = $this.find(".rating_icon")
  const $input = $this.find(".rating_input")
  if ($target.is($icon)) {
    $target
      .addClass("-active")
      .prevAll()
      .addClass("-active")
      .end()
      .nextAll()
      .removeClass("-active")
    $input.val($target.index() + 1)
  }
})