window.addEventListener("click", () => {
  const $phone = document.querySelector(".phone")
  $phone.classList.toggle('-loooooong')
})