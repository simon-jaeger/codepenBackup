$(window).click(() => {
  $(".potion_fill").toggleClass('-full')
})