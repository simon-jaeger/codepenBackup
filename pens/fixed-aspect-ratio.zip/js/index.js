$(window).click(() => {
  $('.ratio').animate({width: '+=1rem'}, 300)
})