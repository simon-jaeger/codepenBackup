// bonus tip:
// for more complex svg shapes you can get the path length with js

// add 1 to avoid rendering issues
const pathLength = 1 + document.querySelector(".circleProg_fill").getTotalLength();
console.log(pathLength);