// utils
////////////////////////////////////////////////////////////////////////////////

// swap two html elements
function swap($elem1, $elem2) {
  const $temp = $("<div style='display: none'>")
  $elem1.before($temp)
  $elem2.before($elem1)
  $temp.before($elem2)
  $temp.remove()
}

// puzzle
////////////////////////////////////////////////////////////////////////////////
const $puzzle = $(".puzzle")
const $num = $(".puzzle_num")
const $numEmpty = $(".puzzle_num.-empty")
const solvedHTML = $puzzle.html()

// initialization: swap it up a bit
swap($puzzle.children().eq(10), $puzzle.children().eq(9))
swap($puzzle.children().eq(9), $puzzle.children().eq(8))
swap($puzzle.children().eq(8), $puzzle.children().eq(4))
swap($puzzle.children().eq(4), $puzzle.children().eq(0))
swap($puzzle.children().eq(0), $puzzle.children().eq(1))
swap($puzzle.children().eq(1), $puzzle.children().eq(2))

// sliding functionality
$num.click(function() {
  const $this = $(this)

  // check if valid num block to move
  if ($this.is($numEmpty)) {
    console.log("llegal: empty num")
    return
  }
  if (
    ![
      $numEmpty.index() - 4,
      $numEmpty.index() - 1,
      $numEmpty.index() + 1,
      $numEmpty.index() + 4
    ].includes($this.index())
  ) {
    console.log("llegal: not an adjecant num")
    return
  }

  // swap num block with empty block
  swap($this, $numEmpty)
  console.log("moved num block")

  // check if solved
  if ($puzzle.html() === solvedHTML) {
    setTimeout(() => alert("you solved the puzzle!"), 100)
  }
})