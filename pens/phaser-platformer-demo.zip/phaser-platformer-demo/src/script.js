// SceneMain
////////////////////////////////////////////////////////////////////////////////
class SceneMain extends Phaser.Scene {
  constructor() {
    super("main")
  }

  preload() {
    this.textures.addBase64('block','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAAxSURBVEhL7c2xDQAACMMw/n+6iAsydUHxA56UXTA1BsgAGSADZIAMkAEyQAboTVCULACJcpwe0atlAAAAAElFTkSuQmCC')
  }

  create() {
    this.cursors = this.input.keyboard.createCursorKeys()

    const h = this.game.canvas.height
    const w = this.game.canvas.width
    const t = 32

    this.add.text(w - 8, 8, `${w}x${h}`).setOrigin(1, 0)

    this.player = this.physics.add.image(w - t, 5 * t, "block")
    this.player
      .setOrigin(0, 0)
      .setCollideWorldBounds(true)
      .setBounce(0.2)

    this.platforms = this.physics.add.staticGroup()
    for (let i = 0; i < 10; i++) {
      this.platforms
        .create(i * t, 9 * t, "block")
        .setOrigin(0, 0)
        .refreshBody()
    }
    for (let i = 0; i < 4; i++) {
      this.platforms
        .create(i * t, 6 * t, "block")
        .setOrigin(0, 0)
        .refreshBody()
    }
    for (let i = 6; i < 10; i++) {
      this.platforms
        .create(i * t, 3 * t, "block")
        .setOrigin(0, 0)
        .refreshBody()
    }

    this.physics.add.collider(this.player, this.platforms)
  }

  update() {
    this.player.setVelocityX(0)
    if (this.cursors.left.isDown) {
      this.player.setVelocityX(-160)
    }
    if (this.cursors.right.isDown) {
      this.player.setVelocityX(160)
    }
    if (this.cursors.up.isDown && this.player.body.touching.down) {
      this.player.setVelocityY(-320)
    }
  }
}

// game
////////////////////////////////////////////////////////////////////////////////
const game = new Phaser.Game({
  type: Phaser.AUTO,
  width: 320,
  height: 320,
  physics: {
    default: "arcade",
    arcade: {
      gravity: { y: 320 },
    },
  },
  scene: SceneMain,
})
