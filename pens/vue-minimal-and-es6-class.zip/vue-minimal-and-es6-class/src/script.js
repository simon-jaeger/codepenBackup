class App {
  el = "#app";
  data = {
    title: "vue minimal + es6 class",
    width: 80,
    height: 80
  };
  vue = new Vue({ el: this.el, data: this.data });

  grow() {
    this.data.width += 10;
    this.data.height += 10;
  }

  shrink() {
    this.data.width -= 10;
    this.data.height -= 10;
  }
}

const app = new App();
