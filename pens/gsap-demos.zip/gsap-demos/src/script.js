TweenMax.to($("#rotation"), 2, {
  rotation: 300,
  repeat: -1,
  yoyo: true
});

TweenMax.fromTo(
  $("#xy"),
  2,
  {
    x: -64,
    yPercent: -100
  },
  {
    x: 64,
    yPercent: 100,
    repeat: -1,
    yoyo: true
  }
);

TweenMax.from($("#scale"), 2, {
  scale: 2,
  ease: Power4.easeInOut,
  delay: 1,
  repeat: -1,
  yoyo: true,
  onStart: () => console.log("scale start")
});

TweenMax.to($("#skew"), 2, {
  skewX: 120,
  repeat: -1,
  yoyo: true
});

TweenMax.to($("#alpha"), 2, {
  autoAlpha: 0.2,
  repeat: -1,
  yoyo: true
});

TweenMax.to($("#color"), 2, {
  backgroundColor: "#404080",
  repeat: -1,
  yoyo: true
});

TweenMax.set($("#rotation3d"), { transformPerspective: 300 });
TweenMax.to($("#rotation3d"), 2, {
  rotationY: 360,
  repeat: -1,
  ease: Power0.easeNone
});

TweenMax.set($("#bounce"), { position: "absolute" });
TweenMax.to($("#bounce"), 1, {
  bottom: 0,
  ease: Bounce.easeOut,
  repeat: -1,
  repeatDelay: 1
});

TweenMax.set($("#elastic"), { position: "absolute" });
TweenMax.from($("#elastic"), 2, {
  left: 0,
  ease: Elastic.easeOut,
  repeat: -1,
  repeatDelay: 1
});

TweenMax.staggerTo(
  $(".stagger"),
  1,
  {
    backgroundColor: "#408040",
    cycle: {
      y: ["-=62", "+=62"]
    },
    repeat: -1,
    yoyo: true
  },
  1
);

// timeline based
////////////////////////////////////////////////////////////////////////////////

const $tl1 = $("#tl1");
const tl1 = new TimelineMax({ repeat: -1, repeatDelay: 1 });
tl1
  .set($tl1, { backgroundColor: "#804040" })
  .to($tl1, 0.5, { xPercent: 100 })
  .to($tl1, 0.5, { yPercent: 100 })
  .add("wait") // label
  .to({}, 0.5, {}) // wait
  .to($tl1, 0.5, { xPercent: -100, ease: Power4.easeOut })
  .to($tl1, 0.5, { yPercent: -100 }, "+=1")
  .to($tl1, 0.5, { xPercent: 100 })
  .to($tl1, 0.5, { yPercent: 0 })
  .to($tl1, 0.5, { xPercent: 0 })
  .add(() => console.log("tl1 end reached"));

const $tl2 = $("#tl2");
const tl2 = new TimelineMax({ repeat: -1, yoyo: true });
tl2
  .set($tl2, { backgroundColor: "#408080" })
  .fromTo(
    $tl2,
    2,
    { xPercent: -100 },
    { xPercent: 100, ease: Power0.easeNone }
  );
tl2
  .timeScale(2) // speed multiplier
  .progress(0.5); // jump percentage based. used seek() for second based.
$tl2.click(() => {
  console.log("tl2: toggling playback");
  tl2.paused(!tl2.paused());
});
