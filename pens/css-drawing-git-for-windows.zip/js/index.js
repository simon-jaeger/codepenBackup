window.addEventListener("click", () => {
  const $git = document.querySelector(".git")
  TweenLite.to($git, 0.2, { rotation: "+=45" })
})