$(".site").click(function () {
  $(this).toggleClass('-red -blue')
})