$(window).on("scroll", () => {
  $(":root").css(
    "--scrollProgress",
    $(window).scrollTop() /
      ($("html")[0].scrollHeight - $("html")[0].clientHeight)
  )
})
