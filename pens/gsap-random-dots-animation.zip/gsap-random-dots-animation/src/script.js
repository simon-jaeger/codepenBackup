addDot()
setInterval(addDot, 500)

function addDot() {
  const dot = $(`<div class="dot"></div>`)
  dot.appendTo($(".site"))
  const tl = new TimelineMax()
  tl.set(dot, {
    width:'8rem',
    height:'8rem',
    position:'absolute',
    borderRadius:'50%',
    backgroundColor:'rgba(255,255,255,0.2)',
    xPercent: -50,
    yPercent: -50,
    x: Math.random() * window.innerWidth,
    y: Math.random() * window.innerHeight,
  })
    .to(dot, 2, { autoAlpha: 0, scale: 3 })
    .add(() => dot.remove())
}
