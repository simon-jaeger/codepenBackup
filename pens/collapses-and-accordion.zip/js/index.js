$(".accordionCollapse .collapse_content, .collapse_content.-slideUp").slideUp(0)

$(".collapse").click(function(e) {
  const $this = $(this)
  const $parent = $this.parent()
  const $target = $(e.target)
  if ($target.is(".collapse_toggle")) {
    const $targetContent = $this.find(".collapse_content")
    $targetContent.slideToggle()
    if ($parent.is(".accordionCollapse")) {
      $parent
        .find(".collapse_content")
        .not($targetContent)
        .slideUp()
    }
  }
})