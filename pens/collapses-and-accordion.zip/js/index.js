

$(".collapse_toggle").click(function() {
  $(this)
    .siblings(".collapse_content")
    .slideToggle()
  if ($(this).parent().parent().is('.accordionCollapse')) {
    $(this)
      .parent()
      .siblings()
      .find(".collapse_content")
      .slideUp()
  }
})