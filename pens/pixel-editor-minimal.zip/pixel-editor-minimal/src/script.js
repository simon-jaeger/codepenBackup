const $canvas = $(".canvas")
const c = $canvas[0].getContext("2d")
const width = $canvas[0].width
const height = $canvas[0].height
const zoom = 40
const color = { on: "#000000", off: "#ffffff" }

$canvas.css("width", width * zoom)
$canvas.css("height", height * zoom)

$canvas.click(({ originalEvent: e }) => {
  const x = Math.floor(e.offsetX / zoom)
  const y = Math.floor(e.offsetY / zoom)
  c.fillStyle = color.on
  c.fillRect(x, y, 1, 1)
})

$("#clear").click(() => {
  c.clearRect(0, 0, width, height)
})

$("#switchColor").click(() => {
  ;[color.on, color.off] = [color.off, color.on]
})
