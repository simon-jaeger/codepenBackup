$('.site').click(function () {
  $(this).toggleClass('-visualized')
})