$(window).click(() => {
  $(".cake_bg").toggleClass("-big");
});