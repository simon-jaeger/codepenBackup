// vars
////////////////////////////////////////////////////////////////////////////////
const $score = document.querySelector(".score")
const $canvas: HTMLCanvasElement = document.querySelector(".canvas")
const c = $canvas.getContext("2d")
const w = $canvas.width
const h = $canvas.height
let v = { x: 1, y: 0 }
let inputLocked = false

let snake = [
  { x: 4, y: 0 },
  { x: 3, y: 0 },
  { x: 2, y: 0 },
  { x: 1, y: 0 },
  { x: 0, y: 0 },
]
let snakeColor = "#d0d0d0"

let food = { x: 8, y: 0 }
const foodColor = "#1fa050"

// functions
////////////////////////////////////////////////////////////////////////////////
function update() {
  const _lastSnakePart = { ...snake[snake.length - 1] }

  // snake move
  for (let i = snake.length - 1; i >= 1; i--) {
    snake[i].x = snake[i - 1].x
    snake[i].y = snake[i - 1].y
  }
  snake[0].x += v.x
  snake[0].y += v.y

  // snake out of bound check
  if (snake[0].x >= w) {
    snake[0].x = 0
  } else if (snake[0].x < 0) {
    snake[0].x = w - 1
  } else if (snake[0].y >= h) {
    snake[0].y = 0
  } else if (snake[0].y < 0) {
    snake[0].y = h - 1
  }

  // snake food collision
  if (snake[0].x === food.x && snake[0].y === food.y) {
    $score.textContent = "" + (+$score.textContent + 10)
    snake.push(_lastSnakePart)
    do {
      food.x = Math.floor(Math.random() * w)
      food.y = Math.floor(Math.random() * h)
    } while (snake.filter(p => p.x === food.x && p.y === food.y).length)
  }

  // snake self collision
  if (
    snake.slice(1).filter(p => p.x === snake[0].x && p.y === snake[0].y).length
  ) {
    // reset game state
    $score.textContent = "0"
    snake = [
      { x: 4, y: 0 },
      { x: 3, y: 0 },
      { x: 2, y: 0 },
      { x: 1, y: 0 },
      { x: 0, y: 0 },
    ]
    v = { x: 1, y: 0 }
    food = { x: 8, y: 0 }
  }

  // unlock input
  inputLocked = false
}

function render() {
  c.clearRect(0, 0, w, h)

  c.fillStyle = foodColor
  c.fillRect(food.x, food.y, 1, 1)

  c.fillStyle = snakeColor
  snake.forEach(p => c.fillRect(p.x, p.y, 1, 1))
}

// event listener
////////////////////////////////////////////////////////////////////////////////
window.addEventListener("keydown", (e: KeyboardEvent) => {
  if (inputLocked) return
  inputLocked = true
  if (e.key === "ArrowUp" && v.y !== 1) {
    v = { x: 0, y: -1 }
  } else if (e.key === "ArrowRight" && v.x !== -1) {
    v = { x: 1, y: 0 }
  } else if (e.key === "ArrowDown" && v.y !== -1) {
    v = { x: 0, y: 1 }
  } else if (e.key === "ArrowLeft" && v.x !== 1) {
    v = { x: -1, y: 0 }
  }
})

// game loop
////////////////////////////////////////////////////////////////////////////////
render()
setInterval(() => {
  update()
  render()
}, 200)
