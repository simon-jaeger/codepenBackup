const tl = new TimelineMax({ repeat: -1, yoyo: true });
tl.staggerTo(".ball", 1, {
  autoAlpha: 0,
  cycle: {
    yPercent: [-100, 100]
  },
  ease: Power3.easeInOut,
  stagger: 0.25
});