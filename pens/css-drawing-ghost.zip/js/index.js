$(window).click(() => {
  $('.ghost_eye').toggleClass('-lookRight')
})