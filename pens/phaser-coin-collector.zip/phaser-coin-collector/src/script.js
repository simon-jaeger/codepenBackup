// globals
////////////////////////////////////////////////////////////////////////////////
const g = {}
const w = 640
const h = 640
const t = 32

// scene
////////////////////////////////////////////////////////////////////////////////
class scene extends Phaser.Scene {
  preload() {
    let x

    x = this.textures.createCanvas("player", 2*t, 2*t)
    x.context.fillStyle = "#cccccc"
    x.context.fillRect(0, 0, 2*t, 2*t)
    x.refresh()

    x = this.textures.createCanvas("coin", t, t)
    x.context.fillStyle = "#F1E431"
    x.context.fillRect(0, 0, t, t)
    x.refresh()
  }

  create() {
    this.arrow = this.input.keyboard.createCursorKeys()

    g.score = 0

    g.player = this.physics.add
      .image(0, 3*t, "player")
      .setOrigin(0, 0)
      .setCollideWorldBounds(true)
    g.player.speed=300

    g.coin = this.physics.add.image(5 * t, 3*t, "coin").setOrigin(0, 0)
  }

  update() {
    g.player.setVelocity(0)
    if (this.arrow.right.isDown) {
      g.player.setVelocityX(g.player.speed)
    } else if (this.arrow.left.isDown) {
      g.player.setVelocityX(-g.player.speed)
    }
    if (this.arrow.down.isDown) {
      g.player.setVelocityY(g.player.speed)
    } else if (this.arrow.up.isDown) {
      g.player.setVelocityY(-g.player.speed)
    }

    if (this.physics.overlap(g.player, g.coin)) {
      this.hitCoin()
    }

    this.updateUI()
  }

  updateUI() {
    document.querySelector('[data-bind="score"]').textContent = g.score
  }

  hitCoin() {
    g.coin.x = Phaser.Math.Between(0, w - t)
    g.coin.y = Phaser.Math.Between(0, h - t)

    g.score += 10
  }
}

// game
////////////////////////////////////////////////////////////////////////////////
new Phaser.Game({
  width: w,
  height: h,
  backgroundColor: "#000000",
  pixelArt: true,
  parent: "game",
  physics: {
    default: "arcade",
    arcade: {
      gravity: { y: 0 },
      debug: true,
    },
  },
  scene,
})
