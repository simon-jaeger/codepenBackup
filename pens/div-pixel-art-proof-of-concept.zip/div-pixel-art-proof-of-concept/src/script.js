$(".canvas").click(e => {
  $(e.target).toggleClass("-filled");
});
